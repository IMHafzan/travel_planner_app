package com.example.ai_travel_planner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
