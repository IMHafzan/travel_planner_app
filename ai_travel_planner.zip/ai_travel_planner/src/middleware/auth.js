import jwt from 'jsonwebtoken';
import { asyncHandler } from './async.js';
import { User } from '../models/User.js';

export const protect = asyncHandler(async (req, res, next) => {
  let token;
  if (req.headers.authorization?.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) {
    return res.status(401).json({ 
      status: 'fail', 
      message: 'Not authorized to access this resource' 
    });
  }

  const decoded = jwt.verify(token, process.env.JWT_SECRET);
  const user = await User.findById(decoded.id);
  
  if (!user) {
    return res.status(404).json({ 
      status: 'fail', 
      message: 'User not found' 
    });
  }

  req.user = user;
  next();
}); 