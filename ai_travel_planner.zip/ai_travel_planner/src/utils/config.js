import dotenv from 'dotenv';

dotenv.config();

export const config = {
  PORT: process.env.PORT || 3000,
  MONGODB_URI: process.env.MONGODB_URI,
  JWT_SECRET: process.env.JWT_SECRET,
  DEEPSEEK_API_KEY: process.env.DEEPSEEK_API_KEY,
  CORS_ORIGINS: process.env.CORS_ORIGINS?.split(',') || '*',
  NODE_ENV: process.env.NODE_ENV || 'development'
}; 