import axios from 'axios';
import logger from '../utils/logger.js';

export class DeepSeekClient {
  static async generatePlan(params) {
    logger.info('Generating plan for:', params);
    
    try {
      const response = await axios.post(
        'https://api.deepseek.com/v1/chat/completions',
        {
          model: 'deepseek-chat-1.3',
          messages: params.messages,
          temperature: 0.7,
          max_tokens: 1000,
          stream: false
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.DEEPSEEK_API_KEY}`
          },
          timeout: 15000
        }
      );

      const content = response.data.choices[0].message.content;
      return this._parseAndValidateResponse(content);
    } catch (error) {
      logger.error(`DeepSeek API Error: ${error.message}`);
      throw new Error('Failed to generate plan. Please try again later.');
    }
  }

  static _parseAndValidateResponse(content) {
    try {
      const jsonString = content.replace(/```json/g, '').replace(/```/g, '');
      const plan = JSON.parse(jsonString);
      
      // Validate response structure
      if (!plan.days || !Array.isArray(plan.days)) {
        throw new Error('Invalid plan format from API');
      }
      
      return plan;
    } catch (error) {
      logger.error(`Response Parsing Error: ${error.message}`);
      throw new Error('Invalid response format from AI service');
    }
  }
}

export async function generatePlan(tripData) {
  logger.info('Generating plan for:', tripData);
  
  // Mock response for testing
  return {
    ...tripData,
    days: [
      {
        date: tripData.start_date,
        activities: [
          {
            time: "09:00",
            title: "Sample Activity",
            description: "A sample activity description"
          }
        ]
      }
    ]
  };
} 