import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import mongoose from 'mongoose';
import { config } from './utils/config.js';
import { errorHandler } from './middleware/error.js';
import { limiter } from './middleware/rateLimit.js';
import tripRoutes from './routes/tripRoutes.js';
import authRoutes from './routes/authRoutes.js';

const app = express();

// Security middleware
app.use(helmet());
app.use(cors({ origin: config.CORS_ORIGINS }));
app.use(express.json({ limit: '10kb' }));
app.use(limiter);

// Database connection
mongoose.connect(config.MONGODB_URI)
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => {
    console.error('Database connection error:', err);
    process.exit(1);
  });

// Routes
app.use('/api/v1/trips', tripRoutes);
app.use('/api/v1/auth', authRoutes);

// Error handling
app.use(errorHandler);

const port = config.PORT || 3000;
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
}); 