import express from 'express';
import { DeepSeekClient } from '../services/deepseek_service.js';
import { validatePlanRequest } from '../utils/validators.js';

const router = express.Router();

router.post('/generate-plan', async (req, res) => {
  try {
    const { destination, start_date, end_date, mood } = validatePlanRequest(req.body);
    
    const prompt = `Generate a ${mood.toLowerCase()} travel plan for ${destination} from ${start_date} to ${end_date}. 
      Format as JSON with days containing date (YYYY-MM-DD) and activities array with time, title, description.`;
    
    const plan = await DeepSeekClient.generatePlan({
      model: 'deepseek-chat',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.7,
      max_tokens: 1000
    });

    res.json(plan);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router; 