import mongoose from 'mongoose';

const activitySchema = new mongoose.Schema({
  time: { type: String, required: true },
  title: { type: String, required: true },
  description: { type: String, required: true }
});

const daySchema = new mongoose.Schema({
  date: { type: Date, required: true },
  activities: [activitySchema]
});

const tripSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  destination: { type: String, required: true },
  startDate: { type: Date, required: true },
  endDate: { type: Date, required: true },
  mood: { type: String, required: true },
  days: [daySchema],
  createdAt: { type: Date, default: Date.now }
});

tripSchema.index({ user: 1, createdAt: -1 });

export default mongoose.model('Trip', tripSchema); 