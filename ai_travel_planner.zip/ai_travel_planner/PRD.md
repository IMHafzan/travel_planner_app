**Product Requirements Document (PRD): AI Travel Planner**

---

### **1. Overview**
**Objective**: Build an AI-powered travel planner app using Flutter (UI), Node.js (backend), and DeepSeek API (AI plan generation).  
**Core Features**:  
- User inputs: Destination, dates, mood.  
- AI-generated travel plan via DeepSeek API.  
- Plan display, regeneration, and local saving.  
- History and settings management.  

---

### **2. Step-by-Step Implementation Guide**  
#### **2.1 UI Components (Flutter)**  
1. **Input Form Screen** (`trip_input_form.dart`):  
   - Fields: Destination (text), Start/End Date (date picker), Mood (dropdown: Adventure, Relaxation, Cultural, etc.).  
   - Validation: Ensure dates are valid (end ≥ start), fields non-empty.  
   - Submit Button: Triggers API call.  

2. **Loading State** (`loading_indicator.dart`):  
   - Show circular progress indicator with "Generating your plan..." text.  

3. **Plan Display Screen** (`travel_plan_screen.dart`):  
   - Sections: Daily schedule (Day 1, Day 2), activities with time slots/descriptions.  
   - Action Buttons: "Regenerate Plan", "Save Plan".  

4. **Error Handling**:  
   - SnackBar for API errors (e.g., "Failed to generate plan. Retry?").  
   - AlertDialog for invalid inputs (e.g., "End date cannot be before start date").  

5. **History Screen** (`history_screen.dart`):  
   - ListView of saved plans (trip title, destination, dates).  
   - Tap to view details.  

6. **Settings Screen** (`settings_screen.dart`):  
   - TextField for API key input (secure entry).  
   - "Clear History" button.  

#### **2.2 Backend (Node.js)**  
1. **API Routes**:  
   - `POST /generate-plan`: Accepts user inputs, calls DeepSeek API, returns structured plan.  
   - `POST /save-plan`: Saves plan to local database (e.g., SQLite).  

2. **Prompt Engineering**:  
   - System message:  
     ```  
     "Generate a travel plan in JSON format for {destination} from {start_date} to {end_date}. 
     Mood: {mood}. Include days with time slots, activity titles, and descriptions."  
     ```  
   - Example response format:  
     ```json
     {
       "days": [
         {
           "date": "2024-06-01",
           "activities": [
             {"time": "09:00", "title": "Visit Museum", "description": "..."}
           ]
         }
       ]
     }
     ```

#### **2.3 AI Integration**  
1. **DeepSeek API Call**:  
   - Use `deepseek-chat` model.  
   - Parameters: `temperature=0.7`, `max_tokens=1000`.  
   - Error handling: Retry on rate limits, validate JSON response.  

#### **2.4 State Management**  
- **Riverpod Providers**:  
  - `TripProvider`: Manages form data, API calls, and generated plan.  
  - `HistoryProvider`: Handles saved plans (CRUD operations).  

#### **2.5 Edge Cases**  
- **Network Issues**: Show "No internet" banner.  
- **Empty API Response**: Display "Could not generate plan. Try again."  
- **Invalid Dates**: Auto-correct end date to match start date.  
- **API Key Failure**: Guide user to Settings screen.  

---

### **3. File Structure**  
#### **Flutter Project**  
```
lib/
├── models/
│   ├── trip_model.dart      # Trip, Activity, Day models
│   └── api_response.dart    # API success/error wrapper
├── services/
│   ├── api_service.dart     # HTTP client for backend calls
│   └── storage_service.dart # Hive/SharedPreferences for local saves
├── providers/
│   ├── trip_provider.dart   # State for form/plan
│   └── history_provider.dart
├── views/
│   ├── home_view.dart       # Input form
│   ├── plan_view.dart       # Generated plan display
│   ├── history_view.dart    # Saved plans list
│   └── settings_view.dart   
└── widgets/
    ├── date_picker.dart     # Custom date picker
    └── plan_item.dart       # Activity list tile
```

#### **Node.js Backend**  
```
src/
├── routes/
│   ├── generate-plan.js     # Calls DeepSeek API
│   └── save-plan.js         # Saves to database
├── services/
│   └── deepseek_service.js  # API config and request handler
└── utils/
    ├── config.js            # API key management
    └── logger.js            # Error logging
```

---

### **4. API Routes (Node.js)**  
1. **POST /generate-plan**  
   - Request Body:  
     ```json
     {
       "destination": "Paris",
       "start_date": "2024-06-01",
       "end_date": "2024-06-05",
       "mood": "Cultural"
     }
     ```  
   - Response:  
     ```json
     {
       "days": [{ "date": "2024-06-01", "activities": [...] }]
     }
     ```

2. **POST /save-plan**  
   - Request Body: Full plan JSON.  
   - Response: `{ "status": "success", "id": "123" }`.  

---

### **5. Testing Plan**  
- **UI Tests**: Form validation, navigation flows.  
- **API Tests**: Mock DeepSeek responses, error scenarios.  
- **Edge Cases**: Past dates, long activity descriptions.  

---

### **6. Security & Compliance**  
- **API Key**: Stored in Node.js environment variables, never exposed client-side.  
- **Data Encryption**: Local storage (Hive) uses AES encryption.  

---

**Final Notes**:  
- Use `deepseek-reasoner` for complex itineraries (e.g., multi-city trips).  
- Add rate limiting (e.g., 5 requests/hour) to prevent abuse.  
- Document code with /// comments for Dart and JSDoc for Node.js.  
