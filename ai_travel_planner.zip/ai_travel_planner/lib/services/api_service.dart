import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/trip_model.dart';

class ApiService {
  final String _baseUrl;
  static const _timeout = Duration(seconds: 30);

  ApiService({required String baseUrl}) : _baseUrl = baseUrl;

  Future<Trip> generatePlan(Trip trip) async {
    print('Sending request to: $_baseUrl/generate-plan');
    print('Payload: ${trip.toJson()}');

    final response = await http
        .post(
          Uri.parse('$_baseUrl/generate-plan'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'destination': trip.destination,
            'start_date': trip.startDate.toIso8601String(),
            'end_date': trip.endDate.toIso8601String(),
            'mood': trip.mood,
          }),
        )
        .timeout(_timeout)
        .catchError((e) {
      print('Network error: $e');
      throw e;
    });

    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');

    if (response.statusCode != 200) {
      throw Exception('Failed to generate plan: ${response.body}');
    }

    return Trip.fromJson(jsonDecode(response.body));
  }
}

final apiServiceProvider = Provider<ApiService>((ref) {
  const baseUrl = String.fromEnvironment('API_BASE_URL',
      defaultValue: 'http://10.0.2.2:3000/api' // Android emulator localhost
      );
  return ApiService(baseUrl: baseUrl);
});
