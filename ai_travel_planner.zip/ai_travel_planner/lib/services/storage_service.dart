import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/trip_model.dart';
import 'package:hive/hive.dart';

class StorageService {
  static const _boxName = 'travelPlans';
  static const _apiKeyBox = 'api_keys';
  static const _authTokenKey = 'auth_token';
  static const authBoxName = 'auth';
  static const String guestBoxName = 'guest_data';

  Future<Box<Trip>> _openBox() async {
    if (!Hive.isAdapterRegistered(TripAdapter().typeId)) {
      Hive.registerAdapter(TripAdapter());
    }
    return Hive.openBox<Trip>(_boxName);
  }

  Future<void> saveTrip(Trip plan) async {
    final box = await _openBox();
    await box.add(plan);
  }

  Future<List<Trip>> getSavedTrips() async {
    final box = await _openBox();
    return box.values.toList();
  }

  Future<void> clearTrips() async {
    final box = await _openBox();
    await box.clear();
  }

  Future<void> saveApiKey(String key) async {
    final box = await Hive.openBox(_apiKeyBox);
    await box.put('deepseek_key', key);
  }

  String? getApiKey() {
    final box = Hive.box(_apiKeyBox);
    return box.get('deepseek_key');
  }

  Future<String?> getAuthToken() async {
    final box = await Hive.openBox('auth');
    return box.get(_authTokenKey);
  }

  Future<void> saveAuthToken(String token) async {
    final box = await Hive.openBox('auth');
    await box.put(_authTokenKey, token);
  }

  Future<void> deleteAuthToken() async {
    final box = await Hive.openBox('auth');
    await box.delete(_authTokenKey);
  }

  Future<Box> openGuestBox() async {
    return await Hive.openBox(guestBoxName);
  }

  Future<void> clearGuestData() async {
    final box = await Hive.openBox(guestBoxName);
    await box.clear();
  }
}

final storageServiceProvider =
    Provider<StorageService>((ref) => StorageService());
