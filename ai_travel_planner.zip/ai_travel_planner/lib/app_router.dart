import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'models/trip_model.dart';
import 'views/home_view.dart';
import 'views/plan_view.dart';
import 'views/history_view.dart';
import 'views/settings_view.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'views/splash_screen.dart';
import 'views/auth_screen.dart';
import '../providers/auth_provider.dart';

final routerProvider = Provider((ref) => router);

final router = GoRouter(
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const SplashScreen(),
    ),
    GoRoute(
      path: '/auth',
      builder: (context, state) => const AuthScreen(),
    ),
    GoRoute(
      path: '/home',
      builder: (context, state) => const HomeView(),
      routes: [
        GoRoute(
          path: 'plan',
          builder: (context, state) => PlanView(
            plan: state.extra! as Trip,
            onRegenerate: () => context.pop(),
            onSave: () => context.pop(),
          ),
        ),
        GoRoute(
          path: 'history',
          builder: (context, state) => HistoryView(
            trips: [],
            onTap: null,
          ),
        ),
        GoRoute(
          path: 'settings',
          builder: (context, state) => const SettingsView(),
        ),
      ],
    ),
  ],
  redirect: (context, state) {
    final container = ProviderScope.containerOf(context);
    final authState = container.read(authProvider);
    final isLoggedIn = authState.value != null;
    final isGuest = authState.value?['isGuest'] == true;
    final isAuthRoute = state.uri.path == '/auth';

    if ((!isLoggedIn && !isGuest) && !isAuthRoute) return '/auth';
    if ((isLoggedIn || isGuest) && isAuthRoute) return '/home';
    return null;
  },
);
