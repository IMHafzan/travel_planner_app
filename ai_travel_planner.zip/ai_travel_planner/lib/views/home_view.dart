import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/trip_model.dart';
import '../widgets/date_picker_field.dart';
import 'package:flutter/animation.dart';

class HomeView extends ConsumerWidget {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Travel Planner'),
        elevation: 4,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _WelcomeHeader(),
              const SizedBox(height: 30),
              const TripInputForm(),
            ],
          ),
        ),
      ),
    );
  }
}

class TripInputForm extends ConsumerStatefulWidget {
  const TripInputForm({super.key});

  @override
  ConsumerState<TripInputForm> createState() => _TripInputFormState();
}

class _TripInputFormState extends ConsumerState<TripInputForm> {
  final _formKey = GlobalKey<FormState>();
  final _destinationController = TextEditingController();
  DateTime _startDate = DateTime.now();
  DateTime _endDate = DateTime.now().add(const Duration(days: 1));
  String _selectedMood = 'Adventure';

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      print('Form validated successfully');
      final trip = Trip(
        destination: _destinationController.text,
        startDate: _startDate,
        endDate: _endDate,
        mood: _selectedMood,
      );
      ref.read(tripProvider.notifier).generatePlan(trip);
    } else {
      print('Form validation failed');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          TextFormField(
            controller: _destinationController,
            decoration: const InputDecoration(
              labelText: 'Destination',
              hintText: 'Enter your destination',
              prefixIcon: Icon(Icons.location_on),
            ),
            validator: (value) =>
                value?.isEmpty ?? true ? 'Please enter a destination' : null,
          ),
          const SizedBox(height: 20),
          DatePickerField(
            label: 'Start Date',
            selectedDate: _startDate,
            onDateSelected: (date) => setState(() => _startDate = date),
          ),
          const SizedBox(height: 20),
          DatePickerField(
            label: 'End Date',
            selectedDate: _endDate,
            onDateSelected: (date) => setState(() {
              if (date.isBefore(_startDate)) {
                _endDate = _startDate;
              } else {
                _endDate = date;
              }
            }),
          ),
          const SizedBox(height: 20),
          DropdownButtonFormField<String>(
            value: _selectedMood,
            items: const [
              DropdownMenuItem(value: 'Adventure', child: Text('Adventure')),
              DropdownMenuItem(value: 'Relaxation', child: Text('Relaxation')),
              DropdownMenuItem(value: 'Cultural', child: Text('Cultural')),
              DropdownMenuItem(value: 'Foodie', child: Text('Foodie')),
              DropdownMenuItem(value: 'Nature', child: Text('Nature')),
            ],
            onChanged: (value) => setState(() => _selectedMood = value!),
            decoration: const InputDecoration(
              labelText: 'Travel Mood',
              prefixIcon: Icon(Icons.mood),
            ),
          ),
          const SizedBox(height: 30),
          ElevatedButton(
            onPressed: _submitForm,
            child: const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Text('Generate Plan', style: TextStyle(fontSize: 16)),
            ),
          ),
        ],
      ),
    );
  }
}

class _WelcomeHeader extends StatefulWidget {
  @override
  __WelcomeHeaderState createState() => __WelcomeHeaderState();
}

class __WelcomeHeaderState extends State<_WelcomeHeader>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _rotateAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 8),
      vsync: this,
    )..repeat();

    _rotateAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.linear,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blue.shade100, Colors.blue.shade50],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.shade100,
            blurRadius: 10,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Row(
        children: [
          RotationTransition(
            turns: _rotateAnimation,
            child: Icon(
              Icons.travel_explore,
              size: 40,
              color: Colors.blue.shade800,
            ),
          ),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Where to next?',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: Colors.blue.shade900,
                      ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Let AI craft your perfect itinerary based on destination, dates, and travel style!',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.blue.shade800,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}
