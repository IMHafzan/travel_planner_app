import 'package:flutter/material.dart';
import '../models/trip_model.dart';

class HistoryView extends StatelessWidget {
  final List<Trip> trips;
  final void Function(Trip)? onTap;

  const HistoryView({
    super.key,
    required this.trips,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Trip History')),
      body: trips.isEmpty
          ? const Center(child: Text('No saved trips yet!'))
          : ListView.builder(
              itemCount: trips.length,
              itemBuilder: (context, index) {
                final trip = trips[index];
                return ListTile(
                  leading: const Icon(Icons.work_history),
                  title: Text(trip.destination),
                  subtitle: Text(
                    '${_formatDate(trip.startDate)} - ${_formatDate(trip.endDate)}',
                  ),
                  trailing: Text(trip.mood),
                  onTap: () => onTap?.call(trip),
                );
              },
            ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }
}
