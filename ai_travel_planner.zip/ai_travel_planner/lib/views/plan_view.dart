import 'package:flutter/material.dart';
import '../models/trip_model.dart';

class PlanView extends StatelessWidget {
  final Trip plan;
  final VoidCallback onRegenerate;
  final VoidCallback onSave;

  const PlanView({
    super.key,
    required this.plan,
    required this.onRegenerate,
    required this.onSave,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(plan.destination),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: onRegenerate,
            tooltip: 'Regenerate Plan',
          ),
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: onSave,
            tooltip: 'Save Plan',
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: plan.days.length,
        itemBuilder: (context, dayIndex) {
          final day = plan.days[dayIndex];
          return Card(
            margin: const EdgeInsets.only(bottom: 16),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Day ${dayIndex + 1} - ${day.date}',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8),
                  ...day.activities.map((activity) => ListTile(
                        leading: const Icon(Icons.schedule),
                        title: Text(activity.title),
                        subtitle: Text(activity.description),
                        trailing: Text(activity.time),
                      )),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
