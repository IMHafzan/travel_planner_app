import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:go_router/go_router.dart';

// App components
import 'app_router.dart';
import 'models/trip_model.dart';
import 'providers/auth_provider.dart';
import 'providers/history_provider.dart';
import 'providers/trip_provider.dart';
import 'services/storage_service.dart';

// Views
import 'views/splash_screen.dart';
import 'views/auth_screen.dart';
import 'views/home_view.dart';
import 'views/plan_view.dart';
import 'views/history_view.dart';
import 'views/settings_view.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Hive
  await Hive.initFlutter();
  Hive.registerAdapter(TripAdapter());
  Hive.registerAdapter(DayAdapter());
  Hive.registerAdapter(ActivityAdapter());

  // Open authentication box
  await Hive.openBox(StorageService.authBoxName);
  await Hive.openBox(StorageService.guestBoxName);

  runApp(const ProviderScope(child: MyApp()));
}

class MyApp extends ConsumerWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(routerProvider);

    return MaterialApp.router(
      title: 'AI Travel Planner',
      theme: _buildAppTheme(),
      debugShowCheckedModeBanner: false,
      routerConfig: router,
    );
  }

  ThemeData _buildAppTheme() {
    return ThemeData(
      colorScheme: ColorScheme.fromSeed(
        seedColor: Colors.blue.shade800,
        primary: Colors.blue.shade800,
        secondary: Colors.amber.shade600,
        background: Colors.blue.shade50,
      ),
      useMaterial3: true,
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.blue.shade800,
        foregroundColor: Colors.white,
        elevation: 4,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(15),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.blue.shade200),
        ),
        filled: true,
        fillColor: Colors.white,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.blue.shade800,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          elevation: 3,
          shadowColor: Colors.blue.shade200,
        ),
      ),
      textTheme: const TextTheme(
        headlineSmall: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.5,
        ),
        bodyLarge: TextStyle(
          fontSize: 16,
          height: 1.5,
        ),
      ),
    );
  }
}

Future<void> migrateGuestData(String userId) async {
  final guestBox = await Hive.openBox(StorageService.guestBoxName);
  final userBox = await Hive.openBox(userId);

  final guestData = guestBox.toMap();
  for (var entry in guestData.entries) {
    await userBox.put(entry.key, entry.value);
  }

  await guestBox.clear();
}
