import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/trip_model.dart';
import '../services/storage_service.dart';

class HistoryNotifier extends StateNotifier<List<Trip>> {
  final Ref ref;
  HistoryNotifier(this.ref) : super([]) {
    _loadSavedPlans();
  }

  Future<void> _loadSavedPlans() async {
    state = await ref.read(storageServiceProvider).getSavedTrips();
  }

  Future<void> savePlan(Trip plan) async {
    await ref.read(storageServiceProvider).saveTrip(plan);
    state = [...state, plan];
  }

  Future<void> clearHistory() async {
    await ref.read(storageServiceProvider).clearTrips();
    state = [];
  }
}

final historyProvider = StateNotifierProvider<HistoryNotifier, List<Trip>>(
  (ref) => HistoryNotifier(ref),
);
