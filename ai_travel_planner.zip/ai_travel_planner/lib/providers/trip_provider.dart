import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/trip_model.dart';
import '../services/api_service.dart';
import '../app_router.dart';

class TripNotifier extends StateNotifier<AsyncValue<Trip>> {
  final Ref ref;
  TripNotifier(this.ref) : super(const AsyncValue.loading());

  Future<void> generatePlan(Trip trip) async {
    print('Generating plan for ${trip.destination}');
    state = const AsyncValue.loading();
    try {
      print('Calling API service...');
      final generatedPlan =
          await ref.read(apiServiceProvider).generatePlan(trip);
      print('Plan received: ${generatedPlan.days.length} days');
      state = AsyncValue.data(generatedPlan);
      ref.read(routerProvider).push('/plan', extra: generatedPlan);
    } catch (e, st) {
      print('Error generating plan: $e');
      state = AsyncValue.error(e, st);
    }
  }
}

final tripProvider = StateNotifierProvider<TripNotifier, AsyncValue<Trip>>(
  (ref) => TripNotifier(ref),
);
