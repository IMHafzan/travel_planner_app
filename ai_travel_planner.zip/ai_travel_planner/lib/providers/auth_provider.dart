import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/auth_service.dart';
import '../services/storage_service.dart';
import 'package:hive/hive.dart';

class AuthNotifier extends StateNotifier<AsyncValue<Map<String, dynamic>>> {
  final Ref ref;
  AuthNotifier(this.ref) : super(const AsyncValue.loading());

  Future<void> login(String email, String password) async {
    try {
      state = const AsyncValue.loading();
      final authService = ref.read(authServiceProvider);
      final response = await authService.login(email, password);
      state = AsyncValue.data(response);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
      rethrow;
    }
  }

  Future<void> signUp(String name, String email, String password) async {
    print('Signup attempt: $email');
    state = const AsyncValue.loading();
    try {
      final authService = ref.read(authServiceProvider);
      final response = await authService.signUp(name, email, password);
      print('Signup successful: ${response['token']}');
      state = AsyncValue.data(response);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  Future<void> checkPersistedAuth() async {
    final storage = ref.read(storageServiceProvider);
    final token = await storage.getAuthToken();

    if (token != null) {
      state = AsyncValue.data({'token': token});
    } else {
      state = const AsyncValue.data({});
    }
  }

  Future<void> logout() async {
    await ref.read(storageServiceProvider).deleteAuthToken();
    state = const AsyncValue.data({});
  }

  void enterAsGuest() {
    state = const AsyncValue.data({'isGuest': true});
  }

  bool get isGuest {
    return state.value?['isGuest'] == true;
  }
}

final authProvider =
    StateNotifierProvider<AuthNotifier, AsyncValue<Map<String, dynamic>>>(
  (ref) => AuthNotifier(ref),
);

final authServiceProvider = Provider<AuthService>((ref) {
  const baseUrl = String.fromEnvironment('API_BASE_URL',
      defaultValue: 'http://10.0.2.2:3000/api/v1');
  return AuthService(baseUrl: baseUrl);
});

final storageServiceProvider = Provider<StorageService>((ref) {
  // Implementation of storage service provider
  // This is a placeholder and should be replaced with the actual implementation
  return StorageService();
});
