import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:state_notifier/state_notifier.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';

@HiveType(typeId: 0)
class Trip {
  @HiveField(0)
  final String destination;
  @HiveField(1)
  final DateTime startDate;
  @HiveField(2)
  final DateTime endDate;
  @HiveField(3)
  final String mood;
  @HiveField(4)
  final List<Day> days;

  Trip({
    required this.destination,
    required this.startDate,
    required this.endDate,
    required this.mood,
    this.days = const [],
  });

  factory Trip.fromJson(Map<String, dynamic> json) {
    return Trip(
      destination: json['destination'],
      startDate: DateTime.parse(json['startDate']),
      endDate: DateTime.parse(json['endDate']),
      mood: json['mood'],
      days: (json['days'] as List).map((d) => Day.fromJson(d)).toList(),
    );
  }

  Map<String, dynamic> toJson() => {
        'destination': destination,
        'startDate': startDate.toIso8601String(),
        'endDate': endDate.toIso8601String(),
        'mood': mood,
        'days': days.map((d) => d.toJson()).toList(),
      };

  Trip copyWith({
    String? destination,
    DateTime? startDate,
    DateTime? endDate,
    String? mood,
    List<Day>? days,
  }) {
    return Trip(
      destination: destination ?? this.destination,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      mood: mood ?? this.mood,
      days: days ?? this.days,
    );
  }
}

@HiveType(typeId: 1)
class Day {
  @HiveField(0)
  final DateTime date;
  @HiveField(1)
  final List<Activity> activities;

  Day({required this.date, required this.activities});

  factory Day.fromJson(Map<String, dynamic> json) {
    return Day(
      date: DateTime.parse(json['date']),
      activities: (json['activities'] as List)
          .map((a) => Activity.fromJson(a))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() => {
        'date': date.toIso8601String(),
        'activities': activities.map((a) => a.toJson()).toList(),
      };
}

@HiveType(typeId: 2)
class Activity {
  @HiveField(0)
  final String time;
  @HiveField(1)
  final String title;
  @HiveField(2)
  final String description;

  Activity(
      {required this.time, required this.title, required this.description});

  factory Activity.fromJson(Map<String, dynamic> json) {
    return Activity(
      time: json['time'],
      title: json['title'],
      description: json['description'],
    );
  }

  Map<String, dynamic> toJson() => {
        'time': time,
        'title': title,
        'description': description,
      };
}

final tripProvider =
    StateNotifierProvider<TripNotifier, Trip?>((ref) => TripNotifier());

class TripNotifier extends StateNotifier<Trip?> {
  TripNotifier() : super(null);

  void generatePlan(Trip trip) {
    state = trip;
  }
}

class TripAdapter extends TypeAdapter<Trip> {
  @override
  final int typeId = 0;

  @override
  Trip read(BinaryReader reader) {
    return Trip.fromJson(reader.readMap().cast());
  }

  @override
  void write(BinaryWriter writer, Trip obj) {
    writer.writeMap(obj.toJson());
  }
}

class DayAdapter extends TypeAdapter<Day> {
  @override
  final int typeId = 1;

  @override
  Day read(BinaryReader reader) {
    return Day.fromJson(reader.readMap().cast());
  }

  @override
  void write(BinaryWriter writer, Day obj) {
    writer.writeMap(obj.toJson());
  }
}

class ActivityAdapter extends TypeAdapter<Activity> {
  @override
  final int typeId = 2;

  @override
  Activity read(BinaryReader reader) {
    return Activity.fromJson(reader.readMap().cast());
  }

  @override
  void write(BinaryWriter writer, Activity obj) {
    writer.writeMap(obj.toJson());
  }
}
